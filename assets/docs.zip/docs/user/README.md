It is [Yass](https://github.com/thindil/yass) project to generate documentation
of it.
